const canvas = document.getElementById("editorCanvas");
const ctx = canvas.getContext("2d");
ctx.imageSmoothingEnabled = false;

const TILE_SIZE = 16;
const MAP_ROWS = 64;
const MAP_COLS = 128;
const VISIBLE_ROWS = canvas.height / TILE_SIZE;
const VISIBLE_COLS = canvas.width / TILE_SIZE;

const map = Array.from({ length: MAP_ROWS }, () => Array(MAP_COLS).fill(-1));
const tileImages = {};
const MAX_TILE_ID = 45;

for (let i = 1; i <= MAX_TILE_ID; i++) {
  const img = new Image();
  img.src = `Assets/Tiles/tile${i}.png`;
  tileImages[i] = img;
}

const tilePicker = document.getElementById("tilePicker");

for (let i = 1; i <= MAX_TILE_ID; i++) {
  const img = document.createElement("img");
  img.src = `Assets/Tiles/tile${i}.png`;
  img.dataset.id = i;
  if (i === 1) img.classList.add("selected");
  tilePicker.appendChild(img);
}

let currentTileID = 1;
tilePicker.addEventListener("click", e => {
  if (e.target.tagName === "IMG") {
    const id = parseInt(e.target.dataset.id);
    currentTileID = id;

    // update selection
    tilePicker.querySelectorAll("img").forEach(img => img.classList.remove("selected"));
    e.target.classList.add("selected");
  }
});

let eraserMode = false;
let isDrawing = false;
let isTouching = false;

let cameraX = 0;
let cameraY = Math.max(0, MAP_ROWS - VISIBLE_ROWS);

/*canvas.addEventListener("click", e => {
  const rect = canvas.getBoundingClientRect();
  const x = Math.floor((e.clientX - rect.left) / TILE_SIZE);
  const y = Math.floor((e.clientY - rect.top) / TILE_SIZE);
  const mapX = x + cameraX;
  const mapY = y + cameraY;
  if (mapY < MAP_ROWS && mapX < MAP_COLS) {
    map[mapY][mapX] = eraserMode ? -1 : currentTileID;
    draw();
  }
});*/

canvas.addEventListener("mousedown", e => {
  isDrawing = true;
  placeTile(e);
});

canvas.addEventListener("mouseup", () => {
  isDrawing = false;
});

canvas.addEventListener("mousemove", e => {
  if (isDrawing) {
    placeTile(e);
  }
});

canvas.addEventListener("touchstart", e => {
  isTouching = true;
  placeTouchTile(e);
});

canvas.addEventListener("touchmove", e => {
  if (isTouching) placeTouchTile(e);
});

window.addEventListener("touchend", () => {
  isTouching = false;
});

document.getElementById("eraseBtn").addEventListener("click", () => {
  eraserMode = !eraserMode;
  document.getElementById("eraseBtn").textContent = eraserMode ? "Eraser ON" : "Eraser";
});

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  for (let y = 0; y < VISIBLE_ROWS; y++) {
    for (let x = 0; x < VISIBLE_COLS; x++) {
      const tile = map[y + cameraY]?.[x + cameraX];
      if (tile >= 0) {
        const img = tileImages[tile];
        if (img.complete) {
          ctx.drawImage(img, x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE);
        }
      }
      ctx.strokeStyle = "#ccb4a5";
      ctx.strokeRect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE);
    }
  }
}

draw();

function placeTile(e) {
  const rect = canvas.getBoundingClientRect();
  const x = Math.floor((e.clientX - rect.left) / TILE_SIZE);
  const y = Math.floor((e.clientY - rect.top) / TILE_SIZE);
  const mapX = x + cameraX;
  const mapY = y + cameraY;
  if (mapY < MAP_ROWS && mapX < MAP_COLS) {
    map[mapY][mapX] = eraserMode ? -1 : currentTileID;
    draw();
  }
}

function placeTouchTile(e) {
  const touch = e.touches[0];
  const rect = canvas.getBoundingClientRect();
  const x = Math.floor((touch.clientX - rect.left) / TILE_SIZE);
  const y = Math.floor((touch.clientY - rect.top) / TILE_SIZE);
  const mapX = x + cameraX;
  const mapY = y + cameraY;
  if (mapY < MAP_ROWS && mapX < MAP_COLS) {
    map[mapY][mapX] = eraserMode ? -1 : currentTileID;
    draw();
  }
}

document.getElementById("saveLocalBtn").addEventListener("click", () => {
    if (!confirm("Save to local?")) return;
  const flat = [];
  for (let y = 0; y < MAP_ROWS; y++) {
    for (let x = 0; x < MAP_COLS; x++) {
      const tile = map[y][x];
      if (tile >= 0) {
        flat.push({ x, y, img: tile });
      }
    }
  }
  localStorage.setItem("tileMap", JSON.stringify(flat, null, 2));
  localStorage.setItem("mapData", JSON.stringify(flat));
  alert("Saved to localStorage!");
});

document.getElementById("loadLocalBtn").addEventListener("click", () => {
  if (!confirm("Load from local?")) return;
  const data = localStorage.getItem("tileMap");
  const mapData = localStorage.getItem("mapData");
  try {
    const dataJson = JSON.parse(data);
    for (let y = 0; y < MAP_ROWS; y++) {
      for (let x = 0; x < MAP_COLS; x++) {
        map[y][x] = -1;
      }
    }
    dataJson.forEach(({ x, y, img }) => {
      if (x < MAP_COLS && y < MAP_ROWS) {
        map[y][x] = img;
      }
    });
    draw();
    console.log(map);
    console.log(JSON.parse(mapData));
  } catch (e) {
    alert("Invalid Data: " + e);
  }
});

// Kamera kontrol
document.getElementById("left").addEventListener( "click", () => {
  cameraX = Math.max(0, cameraX - 1);
  draw();
});
document.getElementById("right").addEventListener("click", () => {
  cameraX = Math.min(MAP_COLS - VISIBLE_COLS, cameraX + 1);
  draw();
});
document.getElementById("up").addEventListener( "click", () => {
  cameraY = Math.max(0, cameraY - 1);
  draw();
});
document.getElementById("down").addEventListener("click", () => {
  cameraY = Math.min(MAP_ROWS - VISIBLE_ROWS, cameraY + 1);
  draw();
});