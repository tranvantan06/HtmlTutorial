import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getDatabase, ref, onValue, set, remove , onDisconnect, get, push } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js";

  //di Firebase: Project Settings > Your apps > pilih ikon gambar </> > (Masukkan nama) > Register > salin firebaseConfig dan tempel
const firebaseConfig = {
  apiKey: "",
  authDomain: "",
  databaseURL: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: "",
  measurementId: ""
};

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

const playerId = "player_" + Math.floor(Math.random() * 999999);
const playerRef = ref(db, `world/players/${playerId}`);
let otherPlayers = {};
let allPlayers = {};

onDisconnect(playerRef).remove();

const TILE_SIZE = 16;

const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
ctx.imageSmoothingEnabled = false;

const spriteImages = {
  idle: new Image(),
  run: new Image(),
  jump: new Image(),
  idleWeapon: new Image(),
  runWeapon: new Image(),
  jumpWeapon: new Image()
};
spriteImages.idle.src = 'Assets/PlayerIdle.png';
spriteImages.run.src = 'Assets/PlayerMove.png';
spriteImages.jump.src = 'Assets/PlayerJump.png';
spriteImages.idleWeapon.src = 'Assets/PlayerIdleWeapon.png';
spriteImages.runWeapon.src = 'Assets/PlayerMoveWeapon.png';
spriteImages.jumpWeapon.src = 'Assets/PlayerJumpWeapon.png';

let keys = {};

const player = {
  hp: 5,
  x: 0 * TILE_SIZE,
  y: 0 * TILE_SIZE,
  spawnX: 0 * TILE_SIZE,
  spawnY: 0 * TILE_SIZE,
  vx: 0,
  vy: 0,
  speed: 3,
  jumpForce: 6,
  jumpCount: 0,
  maxJumps: 2,
  grounded: false,
  facingRight: true,
  animState: "idle",
  ammo: 0,
  maxAmmo: 25,
  frame: 0,
  frameTick: 0,
  frameMax: {
    idle: 1,
    run: 2,
    jump: 1,
    idleWeapon: 1,
    runWeapon: 2,
    jumpWeapon: 1
  },
  frameDelay: 4
};

set(playerRef, {
    x: player.x,
    y: player.y,
    facingRight: player.facingRight,
    animState: player.animState,
    frame: player.frame,
    hp: 5
  });
const gravity = 0.3;

let bullets = [];
const bulletImage = new Image();
bulletImage.src = "Assets/Bullet.png";
let shootCooldown = 0;
const shootDelay = 10;

function shoot() {
  if (player.ammo <= 0) return;
  const dir = player.facingRight ? 1 : -1;
  const bullet = {
    x: player.x + ((TILE_SIZE / 2) * dir),
    y: player.y,
    vx: dir * 10,
    owner: playerId
  };
  const bulletRef = push(ref(db, "world/bullets"));
  set(bulletRef, bullet);
  player.ammo -= 1;
}

onValue(ref(db, "world/bullets"), snapshot => {
  const data = snapshot.val();
  bullets = [];

  for (let id in data) {
    bullets.push({ id, ...data[id] });
  }
});

const tileImages = {};
const TOTAL_TILES = 45;
const solidTileIDs = [3,4,5,6,7,8,9,12,13,14,15,16,17,18,19,24,25,26];

for (let i = 1; i <= TOTAL_TILES; i++) {
  const img = new Image();
  img.src = `Assets/Tiles/tile${i}.png`;
  tileImages[i] = img;
}

const defaultPlatform = ref(db, 'defaultPlatform');
const platformRef = ref(db, `world/platforms`);
let platforms = [];
let voidY = 0;
let platformRects = [];
get(platformRef).then((snapshot) => {
  const data = snapshot.val();
  if (!data || data.length === 0) {
    const localData = JSON.parse(localStorage.getItem("mapData"));
    if (localData) {
      set(platformRef, localData);
      updatePlatforms(localData)
    }
    else {
      get(defaultPlatform).then((Psnapshot) => {
        set(platformRef, Psnapshot.val());
        updatePlatforms(Psnapshot.val());
      })
    }
  } else {
    updatePlatforms(data);
  }
});

function updatePlatforms(data) {
  platforms = data;
  voidY = getVoidY();
  const validTiles = data.filter(p => solidTileIDs.includes(p.img));
  const randomTile = validTiles[Math.floor(Math.random() * validTiles.length)];
  player.spawnX = randomTile.x * TILE_SIZE;
  player.spawnY = (findSpawnY(randomTile.x, validTiles) - 5) * TILE_SIZE;
  player.x = player.spawnX;
  player.y = player.spawnY;
  platformRects = getPlatformRects();
}

const camera = { x: 0, y: 0 };

let weapons = [];
const weaponImage = new Image();
weaponImage.src = "Assets/Weapon.png";

setInterval(() => {
    if (weapons.length < 5) {
      spawnWeapon();
      console.log("spawnWeapon");
    }
  }, 5000);

function spawnWeapon() {
  const validTiles = platforms.filter(p => {
    return solidTileIDs.includes(p.img);
  });

  const randomTile = validTiles[Math.floor(Math.random() * validTiles.length)];
  const weaponData = {
    x: randomTile.x * TILE_SIZE,
    y: findSpawnY(randomTile.x, validTiles) * TILE_SIZE - TILE_SIZE,
  }
  
  const weaponsRef = push(ref(db, "world/weapons"));
  set(weaponsRef, weaponData);
}

onValue(ref(db, "world/weapons"), snapshot => {
  const data = snapshot.val();
  weapons = [];
  for (let id in data) {
    weapons.push({
      id,
      ...data[id]
    });
  }
});

function update() {
  if (player.hp <= 0) {
    respawn();
  }
  player.vx = 0;
  if (keys["ArrowRight"] || keys["right"]) player.vx = player.speed;
  if (keys["ArrowLeft"] || keys["left"]) player.vx = -player.speed;

  player.vy += gravity;
  player.grounded = false;

  player.x += player.vx;
  player.y += player.vy;

  platformRects.forEach(p => {
    const dx = (player.x + TILE_SIZE / 2) - (p.x + TILE_SIZE / 2);
    const dy = (player.y + TILE_SIZE / 2) - (p.y + TILE_SIZE / 2);
    const combinedHalfWidths = (TILE_SIZE + TILE_SIZE) / 2;
    const combinedHalfHeights = (TILE_SIZE + TILE_SIZE) / 2;
  
    if (Math.abs(dx) < combinedHalfWidths && Math.abs(dy) < combinedHalfHeights) {
      const overlapX = combinedHalfWidths - Math.abs(dx);
      const overlapY = combinedHalfHeights - Math.abs(dy);
      if (player.vy < 0) return;
      if (overlapX < overlapY) {
        // Horizontal collision
        if (dx > 0) {
          player.x += overlapX;
        } else {
          player.x -= overlapX;
        }
        player.vx = 0;
      } else {
        if (dy > 0) {
          player.y += overlapY;
          player.vy = 0;
        } else {
          // Player jatuh ke atas platform
          player.y -= overlapY;
          player.vy = 0;
          player.grounded = true;
        }
      }
    }
  });
  
  if (player.y > voidY * TILE_SIZE) {
    respawn();
  }
  
  if (player.vy > 0 && player.grounded === false && player.wasGrounded === true) {
    player.jumpCount = 1;
  }
  if (player.grounded) {
    player.jumpCount = 0;
  }
  player.wasGrounded = player.grounded;
  
  if (!player.grounded) {
    player.animState = player.ammo > 0 ? "jumpWeapon" : "jump";
  } else if (player.vx !== 0) {
    player.animState = player.ammo > 0 ? "runWeapon" : "run";
  } else {
    player.animState = player.ammo > 0 ? "idleWeapon" : "idle";
  }
  if (player.vx > 0) player.facingRight = true;
  if (player.vx < 0) player.facingRight = false;
  
  if (keys["shoot"] && shootCooldown <= 0 && player.ammo > 0) {
    shoot();
    shootCooldown = shootDelay;
  }
  if (shootCooldown > 0) {
    shootCooldown--;
  }
  weapons.forEach(w => {
    if (!w.taken &&
      player.x < w.x + TILE_SIZE &&
      player.x + TILE_SIZE > w.x &&
      player.y < w.y + TILE_SIZE &&
      player.y + TILE_SIZE > w.y) {
        player.ammo = player.maxAmmo;
        remove(ref(db, `world/weapons/${w.id}`));
    }
  });
  
  camera.x = player.x - canvas.width / 2 + TILE_SIZE / 2;
  camera.y = player.y - canvas.height / 2 + TILE_SIZE / 2;
  
  set(ref(db, `world/players/${playerId}/x`), player.x);
  set(ref(db, `world/players/${playerId}/y`), player.y);
  set(ref(db, `world/players/${playerId}/facingRight`), player.facingRight);
  set(ref(db, `world/players/${playerId}/animState`), player.animState);
  set(ref(db, `world/players/${playerId}/frame`), player.frame);
  /*set(playerRef, {
    x: player.x,
    y: player.y,
    facingRight: player.facingRight,
    animState: player.animState,
    frame: player.frame,
  });*/
  
  bullets.forEach(bullet => {
    if (isFirstPlayer() && Object.keys(allPlayers).indexOf(bullet.owner) === -1) {
      remove(ref(db, `world/bullets/${bullet.id}`));
    }
    if (bullet.owner !== playerId) return;
    bullet.x += bullet.vx;
    set(ref(db, `world/bullets/${bullet.id}`), {
      x: bullet.x,
      y: bullet.y,
      vx: bullet.vx,
      owner: bullet.owner,
  });
    
    platformRects.forEach(p => {
      if (
        bullet.x < p.x + TILE_SIZE &&
        bullet.x + TILE_SIZE > p.x &&
        bullet.y < p.y + TILE_SIZE &&
        bullet.y + TILE_SIZE > p.y
      ) {
        remove(ref(db, `world/bullets/${bullet.id}`));
      }
    });
    
    for (let id in otherPlayers) {
      const p = otherPlayers[id];
      if (bullet.x < p.x + TILE_SIZE &&
        bullet.x + TILE_SIZE > p.x &&
        bullet.y < p.y + TILE_SIZE &&
        bullet.y + TILE_SIZE > p.y) {
          const targetRef = ref(db, `world/players/${id}/hp`);
          get(targetRef).then(snap => {
            const currentHp = snap.val() || 5;
            const newHp = Math.max(currentHp - 1, 0);
            set(targetRef, newHp);
          });
          remove(ref(db, `world/bullets/${bullet.id}`));
        }
    };
    if (bullet.x < camera.x - TILE_SIZE || bullet.x > canvas.width + camera.x) {
      remove(ref(db, `world/bullets/${bullet.id}`));
    }
  });
}

const allPlayersRef = ref(db, "world/players");
onValue(allPlayersRef, snapshot => {
  const players = snapshot.val() || {};
  otherPlayers = {};
  for (let id in players) {
    if (id !== playerId) {
      otherPlayers[id] = players[id];
    } else {
      player.hp = players[id].hp;
    }
  }
  allPlayers = players;
});

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  ctx.save();
  ctx.translate(-camera.x, -camera.y);

  platforms.forEach(tile => {
    if (tile.img === 43 || tile.img === 44 || tile.img === 45) return;
    const screenX = tile.x * TILE_SIZE;
    const screenY = tile.y * TILE_SIZE;
    if (
      screenX >= camera.x - TILE_SIZE &&
      screenX < camera.x + canvas.width + TILE_SIZE &&
      screenY >= camera.y - TILE_SIZE &&
      screenY < camera.y + canvas.height + TILE_SIZE
    ) {
      const img = tileImages[tile.img];
      if (img.complete) {
        ctx.drawImage(
          img,
          screenX,
          screenY,
          TILE_SIZE,
          TILE_SIZE
        );
      }
    }
  });
  
  const sprite = spriteImages[player.animState];
  const frameCount = player.frameMax[player.animState];
  const spriteSize = 16;
  
  if (player.frameTick++ > player.frameDelay) {
    player.frameTick = 0;
    player.frame = (player.frame + 1) % frameCount;
  }
  
  if (!player.facingRight) {
    ctx.save();
    ctx.scale(-1, 1);
    ctx.drawImage(
      sprite,
      player.frame * TILE_SIZE, 0,
      TILE_SIZE, TILE_SIZE,
      -player.x - TILE_SIZE, player.y,
      TILE_SIZE, TILE_SIZE
    );
    ctx.restore();
  } else {
    ctx.drawImage(
      sprite,
      player.frame * TILE_SIZE, 0,
      TILE_SIZE, TILE_SIZE,
      player.x, player.y,
      TILE_SIZE, TILE_SIZE
    );
  }
  drawHpBar(player.x + TILE_SIZE, player.y, player.hp);
  if (player.ammo > 0) drawAmmoBar(player.x + TILE_SIZE + 4, player.y, player.ammo, player.maxAmmo);
  
  for (let id in otherPlayers) {
    const p = otherPlayers[id];
    const screenX = p.x;
    const screenY = p.y;
    if (
      screenX >= camera.x - TILE_SIZE &&
      screenX < camera.x + canvas.width + TILE_SIZE &&
      screenY >= camera.y - TILE_SIZE &&
      screenY < camera.y + canvas.height + TILE_SIZE
    ) {
      const Psprite = spriteImages[p.animState];
      if (!p.facingRight) {
        ctx.save();
        ctx.scale(-1, 1);
        ctx.drawImage(
          Psprite,
          p.frame * TILE_SIZE, 0,
          TILE_SIZE, TILE_SIZE,
          -p.x - TILE_SIZE, p.y,
          TILE_SIZE, TILE_SIZE
        );
        ctx.restore();
      } else {
        ctx.drawImage(
          Psprite,
          p.frame * TILE_SIZE, 0,
          TILE_SIZE, TILE_SIZE,
          p.x, p.y,
          TILE_SIZE, TILE_SIZE
        );
      }
    }
    drawHpBar(p.x + TILE_SIZE, p.y, p.hp);
  }
  
  bullets.forEach(b => {
    if (bulletImage.complete) {
      if (b.vx < 0) {
        ctx.save();
        ctx.scale(-1, 1);
        ctx.drawImage(
          bulletImage,
          -b.x - TILE_SIZE,
          b.y,
          TILE_SIZE,
          TILE_SIZE
        );
        ctx.restore();
      } else {
        ctx.drawImage(
          bulletImage,
          b.x,
          b.y,
          TILE_SIZE,
          TILE_SIZE
        );
      }
    }
  });
  
  weapons.forEach(w => {
    const screenX = w.x;
    const screenY = w.y;
    if (
      screenX >= camera.x - TILE_SIZE &&
      screenX < camera.x + canvas.width + TILE_SIZE &&
      screenY >= camera.y - TILE_SIZE &&
      screenY < camera.y + canvas.height + TILE_SIZE
    ) {
      if (weaponImage.complete) {
        ctx.drawImage(weaponImage, w.x, w.y, TILE_SIZE, TILE_SIZE);
      }
    }
  });
  ctx.restore();
}

/*function drawHpBar(x, y, hp, maxHp = 5) {
  const barWidth = 16; // panjang bar
  const barHeight = 4; // tinggi bar
  const padding = 2;

  const ratio = Math.max(0, Math.min(1, hp / maxHp));
  const filledWidth = barWidth * ratio;

  // Latar belakang abu
  ctx.fillStyle = "gray";
  ctx.fillRect(x, y - padding - barHeight, barWidth, barHeight);

  // Isi merah
  ctx.fillStyle = "red";
  ctx.fillRect(x, y - padding - barHeight, filledWidth, barHeight);
}

function drawAmmoBar(x, y, ammo, maxAmmo) {
  const barWidth = 16;
  const barHeight = 4;
  const padding = 2;

  const ratio = Math.max(0, Math.min(1, ammo / maxAmmo));
  const filledWidth = barWidth * ratio;

  // Latar belakang abu
  ctx.fillStyle = "gray";
  ctx.fillRect(x, y - padding - barHeight * 2, barWidth, barHeight);

  // Isi kuning
  ctx.fillStyle = "yellow";
  ctx.fillRect(x, y - padding - barHeight * 2, filledWidth, barHeight);
}*/

function drawHpBar(x, y, hp, maxHp = 5) {
  const barWidth = 4;
  const barHeight = 16; // total tinggi bar
  const padding = 2;

  const ratio = Math.max(0, Math.min(1, hp / maxHp));
  const filledHeight = barHeight * ratio;

  // Gambar latar bar (abu)
  ctx.fillStyle = "gray";
  ctx.fillRect(x + padding, y, barWidth, barHeight);

  // Gambar isi bar (merah)
  ctx.fillStyle = "red";
  ctx.fillRect(x + padding, y + (barHeight - filledHeight), barWidth, filledHeight);
}

function drawAmmoBar(x, y, ammo, maxAmmo) {
  const barWidth = 4;
  const barHeight = 16;
  const padding = 2;

  const ratio = Math.max(0, Math.min(1, ammo / maxAmmo));
  const filledHeight = barHeight * ratio;

  // Background
  ctx.fillStyle = "gray";
  ctx.fillRect(x + padding, y, barWidth, barHeight);

  // Fill
  ctx.fillStyle = "yellow";
  ctx.fillRect(x + padding, y + (barHeight - filledHeight), barWidth, filledHeight);
}


function loop() {
  update();
  draw();
  requestAnimationFrame(loop);
}

loop();

function respawn() {
  if (platforms.length <= 0) return;
  const validTiles = platforms.filter(p => solidTileIDs.includes(p.img));
  const randomTile = validTiles[Math.floor(Math.random() * validTiles.length)];
  player.spawnX = randomTile.x * TILE_SIZE;
  player.spawnY = (findSpawnY(randomTile.x, validTiles) - 5) * TILE_SIZE;
  player.x = player.spawnX;
  player.y = player.spawnY;
  set(playerRef, {
    x: player.x,
    y: player.y,
    facingRight: player.facingRight,
    animState: player.animState,
    frame: player.frame,
    hp: 5
  });
}

function isFirstPlayer() {
  const ids = Object.keys(allPlayers);
  return ids.length > 0 && ids[0] === playerId;
}

function getPlatformRects() {
  return platforms
    .filter(p => solidTileIDs.includes(p.img))
    .map(p => ({
      x: p.x * TILE_SIZE,
      y: p.y * TILE_SIZE,
    }));
}

function getVoidY() {
  let maxY = 0;
  platforms.forEach(p => {
    if (p.y > maxY) {
      maxY = p.y;
    }
  });
  return (maxY + 20);
}

function findSpawnY(xTile, data = platforms) {
  let minY = voidY;
  data.forEach(p => {
    if (p.x === xTile && p.y < minY) {
      minY = p.y;
    }
  });
  return minY;
}

window.addEventListener("keydown", e => keys[e.key] = true);
window.addEventListener("keyup", e => keys[e.key] = false);

document.getElementById("leftBtn").addEventListener("touchstart", () => keys.left = true);
document.getElementById("leftBtn").addEventListener("touchend", () => keys.left = false);
document.getElementById("rightBtn").addEventListener("touchstart", () => keys.right = true);
document.getElementById("rightBtn").addEventListener("touchend", () => keys.right = false);
window.addEventListener("keydown", e => {
  if (e.key === "z") keys.shoot = true;
});
window.addEventListener("keyup", e => {
  if (e.key === "z") keys.shoot = false;
});
document.getElementById("shootBtn").addEventListener("touchstart", () => {
  keys.shoot = true;
});
document.getElementById("shootBtn").addEventListener("touchend", () => {
  keys.shoot = false;
});
document.getElementById("jumpBtn").addEventListener("touchstart", () => {
  if (player.jumpCount < player.maxJumps) {
    player.vy = -player.jumpForce;
    player.jumpCount++;
    player.grounded = false;
  }
});
